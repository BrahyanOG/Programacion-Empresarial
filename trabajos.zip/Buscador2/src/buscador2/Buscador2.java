package buscador2;


public class Buscador2 {

    
    public static void main(String[] args) {
        // Texto
	    String Texto = "25453132131sadasdsadcasa54541245421kdfncasa54545";
	    // Texto que vamos a buscar
	    String Buscado = "casa";
	    // Contador de ocurrencias 
	    int contador = 0;

	    while (Texto.indexOf(Buscado) > -1) {
	      Texto = Texto.substring(Texto.indexOf(
	        Buscado)+Buscado.length(),Texto.length());
	      contador++; 
            }
                System.out.println (contador);
    }
    
}
