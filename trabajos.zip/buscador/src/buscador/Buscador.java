package buscador;


public class Buscador {

  
    public static void main(String[] args) {
        String palabra = "guatemala";
        String letra = "a";
        char[] vector = palabra.toCharArray();
        for(int a =0;a<palabra.length();a++){
            String letrab = String.valueOf(vector[a]);
            if(letra.equalsIgnoreCase(letrab)){
                System.out.println("la letra "+letra+"se encuentra en la posicion  "+(a+1));
            }
            
        }
    }
    
}
