var persona1 = {nombre: "Juan", apellido:"Florez", edad:37, sexo:"M"};
var persona2 = {nombre: "Ana", apellido:"Perez", edad:23, sexo:"F"};

function nombre1(a,b){
    document.getElementById("test").innerHTML = persona1.nombre;
}

function apellido2(a,b){
    document.getElementById("test").innerHTML = persona2.apellido; 
}