var edad = 16;                    //numero
var Apellido = "florez";            //String
var x = {Nombre:"juan", lastName:"Florez"}  //Object

