function suma(a,b){
    document.getElementById("test").innerHTML = a+b;
}

function resta(a,b){
    document.getElementById("test").innerHTML = a-b;
}

function producto(a,b){
    document.getElementById("test").innerHTML = a*b;
}

function divide(a,b){
    document.getElementById("test").innerHTML = a/b;
}