function myFunction(){
    document.getElementById("test").innerHTML = "El texto cambio";
}