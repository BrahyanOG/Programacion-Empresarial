﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BingoAleatorio
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] bingo = new string[] { " B-", "-I-", "-N-", "-G-", "-O " };
            int[,] tableroAle = new int[5, 5];
            string marcar;
            int minimo = 1, maximo = 15;
            var rand = new Random();

            Console.WriteLine(bingo[0] + bingo[1] + bingo[2] + bingo[3] + bingo[4]);
         
            for (int i = 0; i<5; i++)
            {
                for(int j = 0; j < 5; j++)
                {
                    if (i == 2 && j == 2)
                    {
                        tableroAle[i, j] = 0;
                    }
                    else {
                        tableroAle[j, i] = rand.Next(minimo, maximo);
                    }
                   
                }
                minimo = minimo + 15;
                maximo = maximo + 15;
            }


            Tablero tableroBingo = new Tablero(bingo, tableroAle);
            Console.WriteLine(tableroBingo.printMatriz());

            while (1 == 1)
            {
                marcar = Console.ReadLine();
                tableroBingo.Marcar(marcar);
                Console.WriteLine(bingo[0] + bingo[1] + bingo[2] + bingo[3] + bingo[4]);
                Console.WriteLine(tableroBingo.printMatriz());
            }
        }
    }
}
