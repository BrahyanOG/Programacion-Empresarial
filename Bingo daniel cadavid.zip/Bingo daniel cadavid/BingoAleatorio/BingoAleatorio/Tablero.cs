﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BingoAleatorio
{ 
    class Tablero
    {
        private string[] carton;
        private int[,] aleatorios;

        public string[] Carton { get => carton; set => carton = value; }
        public int[,] Aleatorios { get => aleatorios; set => aleatorios = value; }
   

        public Tablero(string[] bingo, int[,] tableroAle)
        {
            Carton = bingo;
            Aleatorios = tableroAle;

        }

        public int[,] Marcar(string posicion)
        {
            string[] split = (posicion.Split(','));

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (i == Convert.ToInt32(split[0]) && j == Convert.ToInt32(split[1]))
                    {
                        Aleatorios[i,j] = 0;
                    }
                }
            }
            return aleatorios;
        }

        public string printMatriz()
        {
            string matriz = " ";
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    matriz += aleatorios[i, j] + "|";
                }
                matriz += "\n";
            }
            return matriz;
        }
    }
}
